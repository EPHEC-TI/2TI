package tp7.model;

//TODO : Me transformer en mod�le !
//Doit �tre observable par les vues
//implique notamment, gr�ce � Observable : 
//* une liste d'observers,
//* des m�thodes : addObserver(), deleteObserver(), notifyObservers(), setChanged(), clearChanged()...
//(voir code de la classe java.util.Observable)
public class Bibliotheque{
	Livre [] livres; 
	
	public Bibliotheque(){
		livres = new Livre[10];
		for(int i = 0; i<10; i++){
			livres[i] = new Livre("Livre "+i);
		}
	}
	public boolean emprunte(int i){
		if(livres[i].emprunte()){
			// TODO On indique le changement, puis on pr�vient tous les observers
			return true;
		}
		return false;
	}
	public void rendre(int i){
		if(livres[i].estEmprunte()){
			livres[i].rendre();
			// TODO On indique le changement, puis on pr�vient tous les observers
		}
	}
	public String toString(){
		String result = "";
		for(int i = 0; i< livres.length; i++){
			result += (i + " : " + livres[i] + "\n") ;
		}
		return result;
	}
	/*
	 * @return une copie des livres de la biblioth�que
	 * clone souvent ) d�conseiller, int�ressant d'en discuter (les cas o� �a fonctionne bien, les copy constructeurs, ...)
	 */
	public Livre [] getLivres(){
		return livres.clone();
	}
}
