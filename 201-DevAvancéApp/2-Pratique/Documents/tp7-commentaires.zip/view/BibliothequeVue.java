package tp7.view;

import java.util.Observer;

import tp7.controller.BibliothequeController;
import tp7.model.Bibliotheque;

//Les vues doivent pouvoir observer le mod�le, d'o� l'impl�mentation de l'interface Observer
//qui implique simplement l'impl�mentation d'une m�thode update(), 
//permettant � l'observale de mettre � jour tous ses observers lorsque n�cessaire.
//Toutes les vues ayant ce m�canisme, repris ici dans une classe abstraite.
public abstract class BibliothequeVue implements Observer{
	
	protected Bibliotheque model;
	protected BibliothequeController controller;
	
	// La vue doit connaitre le mod�le pour pouvoir observer ses changements
	// et le controller pour pouvoir l'informer des actions
	BibliothequeVue(Bibliotheque model, BibliothequeController controller) {
		this.model = model;
		this.controller = controller;
		// le mod�le �tant un Observable, il dispose de la m�thode addObserver
		// TODO : Connexion entre la vue et le modele
	}

	// L'affichage d�pendra du type de vue, n'est donc pas impl�ment� ici, m�thode abstraite
	public abstract void affiche(String string) ;
}
