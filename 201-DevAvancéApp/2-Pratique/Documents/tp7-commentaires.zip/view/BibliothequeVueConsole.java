package tp7.view;
import java.util.InputMismatchException;
import java.util.Observable;
import java.util.Scanner;

import tp7.controller.BibliothequeController;
import tp7.model.Bibliotheque;


public class BibliothequeVueConsole extends BibliothequeVue { // qui impl�mente Observer
	// sert ici � lire en console
	protected Scanner sc;
	
	public BibliothequeVueConsole(Bibliotheque model,
			BibliothequeController controller) {
		super(model, controller);
		// se met � jour lui-m�me ici
		// param�tres fourni habituellement lors de l'appel par l'Observable pas n�cessaires ici
		update(null, null);
		sc = new Scanner(System.in);
		// La classe interne ReadInput impl�mente Runnable, contient donc une m�thode run() 
		// et peut donc �tre lanc�e comme Thread
		new Thread (new ReadInput()).start();	
	}

	// update() de l'interface Observer
	@Override
	public void update(Observable o, Object arg) {
		System.out.println(model);
		printHelp();		
	}
	
	private void printHelp(){
		affiche("Pour emprunter : E + numéro de livre.");
		affiche("Pour rendre : R + numéro de livre.");
	}
	
	private class ReadInput implements Runnable{
		public void run() {
			while(true){
				try{
					String c = sc.next();
					if(c.length()!=1){
						affiche("Format d'input incorrect");
						printHelp();
					}
						
					int i = sc.nextInt();
					if(i<0 || i> 9){
						affiche("Numéro du livre incorrect");
						printHelp(); 
					}
					switch(c){
						case "R" :
							controller.rendreLivre(i);
							break;
						case "E" : 
							controller.emprunteLivre(i);
							break;
						default : 
							affiche("Opération incorrecte");
							printHelp();
					}
				}
				catch(InputMismatchException e){
					affiche("Format d'input incorrect");
					printHelp();
				}
			}
		}
	}

	@Override
	public void affiche(String string) {
		System.out.println(string);
		
	}

}
