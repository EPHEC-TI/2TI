package tp7.controller;

import tp7.model.Bibliotheque;
import tp7.view.BibliothequeVue;

//Les vues doivent pouvoir observer le mod�le, d'o� l'impl�mentation de l'interface java.util.Observer
// implique simplement l'impl�mentation d'une m�thode update(), qui permerttra � l'observable 
// de dire � tous les �l�ments observer de se mettre � jour si besoin
//Toutes les vues ayant ce m�canisme, on le reprend ici dans une classe abstraite, 
// qui sera compl�t�e en fonction des sp�cificit�s de la vue
public class BibliothequeController {
	Bibliotheque model; 
	BibliothequeVue vue;
	
	public BibliothequeController(Bibliotheque model) {
		this.model = model;
	}

	public void emprunteLivre(int numLivre) {	
		//TODO g�rer les affichage dans la vue ou les mises � jours du mod�le en fonction des besoins
	}

	public void rendreLivre(int numLivre) {
		//TODO g�rer les affichage dans la vue ou les mises � jours du mod�le en fonction des besoins
	}

	public void addView(BibliothequeVue vue) {
		this.vue = vue;
		
	}

}
